<?php
    /**
     *  @author Jordi Marset Tortosa
     *  @version 24-09-2025
     */
?>
<footer>
        <!-- Pie de página -->
        <div>
            <img src="/img/img_JordiMarset.jpg" alt="foto cara">
            <h3>Nombre: Jordi Marset Tortosa</h3>
        </div>
</footer>