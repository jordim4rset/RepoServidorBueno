<?php
    /**
     *  @author Jordi Marset Tortosa
     *  @version 24-09-2025
    */
?>
<header>
    <!-- MENÚ ARRIBA, NAVEGAR ENTRE LAS PÁGINAS -->
    <div>
        <nav>
            <ul>
                <li><a href="index.php">INICIO</a></li>
                <li><a href="higherJordi.php">CARTA ALTA</a></li>
                <li><a href="blackjackJordi.php">BLACK JACK</a></li>
            </ul>
        </nav>
    </div>
</header>



