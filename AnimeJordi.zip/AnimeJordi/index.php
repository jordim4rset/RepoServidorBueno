<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/styles/styles.css">
    <title>Index</title>
</head>
<body>
    <?php
        require_once($_SERVER['DOCUMENT_ROOT'] .'/includes/anime.inc.php');
        require_once($_SERVER['DOCUMENT_ROOT'] .'/includes/character.inc.php');
        
        $inazuma = new Anime('Inazuma Eleven','Mark','Joseo','50','1');
        $animes[] = $inazuma;

        $doraemon = new Anime('Doraemon','Nobita','Joseo','455','1999');
        $animes[] = $doraemon;

        $arcane = new Anime('Arcane','Jinx','Josei','20','2020');
        $animes[] = $arcane;

        $markEvans = new Character('Mark Ev4ns','masculino','humano','13');
        $xavierFoster = new Character('Xavier Foster','masculino','humano','14');

        $animes[0]->addCharacter($markEvans);
        $animes[0]->addCharacter($xavierFoster);

        $galio = new Character('Galio','masculino','no humano','100');
        $heimerdinger = new Character('Heimerdinger','masculino','no humano','200');

        $animes[2]->addCharacter($galio);
        $animes[2]->addCharacter($heimerdinger);

        foreach($animes as $anime){
            echo '<div>';
                echo '<h1>'.$anime->title.' Genero: '.$anime->genre.'</h1><br>';
                echo 'Autor: '.$anime->author.'<br>';          
                echo $anime->episodes.' episodios<br><br>';        
                echo '<h3>Personajes</h3>';
                echo '<ul>';
                foreach($anime->characters as $character){
                    echo '<li>'.$character->name.'</li>';
                }
                echo '<ul>';
            echo '</div>';
        }
    ?>



</body>
</html>